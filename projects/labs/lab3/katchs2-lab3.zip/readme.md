Samm Katcher

Although my code for part 1 seems similar to Professor Plotka's, I developed it on my own. I looked at his code for a reference and for
help in places where I was stuck, especially for syntax.
This lab was a good way to dust off my JavaScript skills. JavaScript is so widely used (and quirky) that practicing with it is important.
I didn't know that one can do CSS Manipulation with JavaScript prior to completing this lab, which is an interesting application and a powerful tool.


Resources:
-W3C
-Stack Overflow
-Professor Plotka's code on the LMS

People I discussed this lab with:
-Professor Plotka
-Corey Bryne
-John Fantell
-Connor Griffin