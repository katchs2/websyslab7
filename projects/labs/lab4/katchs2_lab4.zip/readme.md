I found this lab challenging. I have not done much work with JavaScript before this, and I found it helpful and interesting but challenging.
JSON is really useful, I look forward to using it in the future.


Works cited:
Stack overflow
jQuery documentation
W3C
Class notes

People I worked with:
Corey Byrne
Natasha Raguibir
Jason Kim
Corey Burns
John Fantell