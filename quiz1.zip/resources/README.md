Readme File: Samm Katcher
Quiz 1 10/11/16


References:
-My notes from class/ powerpoints/review session with Corey